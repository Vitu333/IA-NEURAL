
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.subheader("Painel Financeiro do CEO")

# Simulação de dados (em produção: integrar com DB)
data = {
    "Data": pd.date_range(start="2024-01-01", periods=10, freq="M"),
    "Receitas ($)": [10000, 12000, 15000, 13000, 16000, 18000, 17000, 19000, 21000, 23000],
    "Despesas ($)": [4000, 5000, 4500, 4700, 4800, 5000, 5300, 5500, 5600, 5800]
}
df = pd.DataFrame(data)
df["Lucro ($)"] = df["Receitas ($)"] - df["Despesas ($)"]

# Mostrar tabela
st.dataframe(df)

# Plot
st.line_chart(df.set_index("Data")[["Receitas ($)", "Despesas ($)", "Lucro ($)"]])

# Exportar planilha
if st.button("Exportar Excel"):
    df.to_excel("painel_financeiro_ceo.xlsx", index=False)
    st.success("Planilha exportada com sucesso!")

# Carteira de Investimento
st.subheader("Carteira de Investimento (Simulador)")

opcoes = ["Tesouro Direto", "CDB", "Criptomoedas", "Ações", "Fundos Imobiliários"]
investimento = st.selectbox("Tipo de Investimento", opcoes)
valor = st.number_input("Valor Inicial ($)", min_value=0.0)
anos = st.slider("Período (anos)", 1, 10)

# Simulação simples de crescimento
taxas = {
    "Tesouro Direto": 0.08,
    "CDB": 0.1,
    "Criptomoedas": 0.25,
    "Ações": 0.15,
    "Fundos Imobiliários": 0.12
}
final = valor * ((1 + taxas[investimento]) ** anos)
st.metric("Valor Estimado Futuro", f"${final:,.2f}")
